'use strict';

module.exports = require('fast-deep-equal');
