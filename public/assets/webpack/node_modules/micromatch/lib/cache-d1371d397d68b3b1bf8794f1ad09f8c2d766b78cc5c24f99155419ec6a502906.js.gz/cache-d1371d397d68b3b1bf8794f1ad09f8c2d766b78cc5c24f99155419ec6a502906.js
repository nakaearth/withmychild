module.exports = new (require('fragment-cache'))();
